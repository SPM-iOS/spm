# shortcut-icon

Extract and render iOS Shortcuts app icons from `.shortcut` files as PNG images.

Handles:
- **AEA1-signed** shortcuts (iOS 16+ sharing format)
- **Plain binary plist** shortcuts
- **Custom image** icons (returns the image directly)
- **Glyph icons** — renders the SF Symbol on the correct background color

## Install

```bash
npm install shortcut-icon
```

## API

```ts
import { extractIconInfo, renderIcon, renderIconBase64 } from "shortcut-icon";
import { readFileSync } from "fs";

const buf = readFileSync("MyShortcut.shortcut");

// Get raw icon metadata
const info = await extractIconInfo(buf);
// {
//   type: "glyph",
//   glyphNumber: 59721,
//   glyphName: "bolt.fill",
//   color: { r: 255, g: 149, b: 0, a: 255 },
//   rawColor: -6750209
// }

// Render as PNG buffer (64x64 default)
const png = await renderIcon(buf, { size: 64 });

// Render as base64 string (for embedding in JSON/HTML)
const b64 = await renderIconBase64(buf);
```

## CLI

```bash
# Print icon info
npx spm-icon MyShortcut.shortcut

# Save as PNG
npx spm-icon MyShortcut.shortcut --png

# Print as base64
npx spm-icon MyShortcut.shortcut --base64

# Custom size
npx spm-icon MyShortcut.shortcut --png --size 128
```

## How it works

1. Strips the AEA1 signing envelope (if present) to get the raw binary plist
2. Parses `WFWorkflowIconGlyphNumber` (SF Symbol Unicode codepoint) and `WFWorkflowIconStartColor` (signed ARGB int)
3. Decodes the color to RGB
4. Looks up the SF Symbol name from the codepoint using the [sf-symbols-online](https://github.com/andrewtavis/sf-symbols-online) name index
5. Fetches the white SVG glyph and composites it onto a rounded-rect background
6. Returns a PNG buffer via [sharp](https://sharp.pixelplumbing.com/)

## Integration with SPM publish API

```ts
import { renderIconBase64 } from "shortcut-icon";

// In your /api/publish handler:
const iconBase64 = await renderIconBase64(shortcutFileBuffer, { size: 64 });
// Store iconBase64 in the package manifest
```
