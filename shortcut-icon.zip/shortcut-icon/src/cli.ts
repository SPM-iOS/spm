#!/usr/bin/env node
/**
 * spm-icon CLI
 *
 * Usage:
 *   spm-icon <file.shortcut>              # print icon info JSON
 *   spm-icon <file.shortcut> --png        # save icon.png
 *   spm-icon <file.shortcut> --base64     # print base64 PNG
 *   spm-icon <file.shortcut> --size 128   # render at 128px (default 64)
 */

import { readFileSync, writeFileSync } from "fs";
import { extractIconInfo, renderIcon, renderIconBase64 } from "./index.js";

const args = process.argv.slice(2);
const file = args.find((a) => !a.startsWith("--"));
const isPng = args.includes("--png");
const isBase64 = args.includes("--base64");
const sizeIdx = args.indexOf("--size");
const size = sizeIdx !== -1 ? parseInt(args[sizeIdx + 1]) : 64;

if (!file) {
  console.error("Usage: spm-icon <file.shortcut> [--png] [--base64] [--size N]");
  process.exit(1);
}

const buf = readFileSync(file);

if (isPng) {
  const png = await renderIcon(buf, { size });
  const outName = file.replace(/\.shortcut$/, "") + "-icon.png";
  writeFileSync(outName, png);
  console.log(`Saved ${outName} (${size}x${size}px)`);
} else if (isBase64) {
  const b64 = await renderIconBase64(buf, { size });
  console.log(b64);
} else {
  const info = await extractIconInfo(buf);
  console.log(JSON.stringify(info, (_, v) => (Buffer.isBuffer(v) ? `<Buffer ${v.length} bytes>` : v), 2));
}
