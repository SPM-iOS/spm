/**
 * shortcut-icon
 * Extract and render iOS Shortcuts app icons from .shortcut files
 *
 * Given a .shortcut file buffer, extracts:
 *   - WFWorkflowIconGlyphNumber  (SF Symbol unicode codepoint)
 *   - WFWorkflowIconStartColor   (signed 32-bit ARGB integer)
 *   - WFWorkflowIconImageData    (custom PNG, if set)
 *
 * Then renders a 64x64 PNG:
 *   - Rounded rect filled with the decoded color
 *   - SF Symbol SVG from sf-symbols-online layered on top (white)
 *
 * If the shortcut has a custom image icon, that is returned directly.
 */

import sharp from "sharp";
import bplist from "bplist-parser";
import fetch from "node-fetch";

const SF_SYMBOLS_BASE =
  "https://raw.githubusercontent.com/andrewtavis/sf-symbols-online/master/glyphs_white";

// Glyph number → SF Symbol name lookup
// The glyph number is the decimal Unicode codepoint in the SF Symbols
// Private Use Area. We need a mapping from codepoint → symbol name.
// We fetch the name index from the sf-symbols-online repo.
let _symbolIndex: Map<number, string> | null = null;

async function getSymbolIndex(): Promise<Map<number, string>> {
  if (_symbolIndex) return _symbolIndex;

  // sf-symbols-online hosts a names.json that maps name → codepoint
  const url =
    "https://raw.githubusercontent.com/andrewtavis/sf-symbols-online/master/names.json";
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch SF symbol index: ${res.status}`);
  const data = (await res.json()) as Record<string, number>;

  // Invert: codepoint → name
  const map = new Map<number, string>();
  for (const [name, codepoint] of Object.entries(data)) {
    map.set(codepoint, name);
  }
  _symbolIndex = map;
  return map;
}

/** Convert signed 32-bit ARGB integer to {r, g, b, a} */
function decodeColor(raw: number): { r: number; g: number; b: number; a: number } {
  // iOS stores it as a signed 32-bit int in ARGB order
  const unsigned = raw >>> 0; // treat as unsigned 32-bit
  const a = (unsigned >>> 24) & 0xff;
  const r = (unsigned >>> 16) & 0xff;
  const g = (unsigned >>> 8) & 0xff;
  const b = unsigned & 0xff;
  return { r, g, b, a };
}

/** Find the bplist start offset inside an AEA1-wrapped .shortcut file */
function findPlistOffset(buf: Buffer): number {
  const marker = Buffer.from("bplist");
  const idx = buf.indexOf(marker);
  if (idx === -1) throw new Error("No bplist found — not a valid .shortcut file");
  return idx;
}

/** Parse a .shortcut buffer and return the plist root dict */
function parseShortcut(buf: Buffer): Record<string, unknown> {
  let plistBuf: Buffer;

  if (buf.slice(0, 4).toString("ascii") === "AEA1") {
    // Signed/wrapped — strip the AEA1 envelope
    const offset = findPlistOffset(buf);
    plistBuf = buf.slice(offset);
  } else if (buf.slice(0, 6).toString("ascii") === "bplist") {
    plistBuf = buf;
  } else {
    // Try brute-force scan
    const marker = Buffer.from("bplist");
    let found = false;
    for (let i = 0; i < buf.length - 6; i++) {
      if (buf.subarray(i, i + 6).toString("ascii") === "bplist") {
        plistBuf = buf.slice(i);
        found = true;
        break;
      }
    }
    if (!found) throw new Error("Could not locate plist data in file");
  }

  const parsed = bplist.parseBuffer(plistBuf!);
  if (!parsed || (parsed as unknown[]).length === 0) throw new Error("Empty plist");
  return parsed[0] as Record<string, unknown>;
}

export interface ShortcutIconInfo {
  type: "glyph" | "image";
  glyphNumber?: number;
  glyphName?: string;
  color?: { r: number; g: number; b: number; a: number };
  rawColor?: number;
  imageData?: Buffer;
}

/** Extract icon metadata from a .shortcut buffer */
export async function extractIconInfo(buf: Buffer): Promise<ShortcutIconInfo> {
  const plist = parseShortcut(buf);
  const icon = (plist.WFWorkflowIcon ?? {}) as Record<string, unknown>;

  const imageData = icon.WFWorkflowIconImageData as Buffer | undefined;
  if (imageData && imageData.length > 0) {
    return { type: "image", imageData };
  }

  const glyphNumber = icon.WFWorkflowIconGlyphNumber as number;
  const rawColor = icon.WFWorkflowIconStartColor as number;
  const color = decodeColor(rawColor);

  // Look up SF Symbol name from codepoint
  let glyphName: string | undefined;
  try {
    const index = await getSymbolIndex();
    glyphName = index.get(glyphNumber);
  } catch {
    // Non-fatal — we'll fall back to codepoint-based SVG URL
  }

  return { type: "glyph", glyphNumber, glyphName, color, rawColor };
}

/** Fetch SVG for a given SF Symbol name */
async function fetchSymbolSvg(name: string): Promise<string | null> {
  const url = `${SF_SYMBOLS_BASE}/${name}.svg`;
  const res = await fetch(url);
  if (!res.ok) return null;
  return res.text();
}

/** Build a rounded-rect SVG background with the given color */
function makeBackground(
  size: number,
  color: { r: number; g: number; b: number; a: number }
): string {
  const { r, g, b } = color;
  const radius = Math.round(size * 0.2237); // matches iOS icon corner radius ratio
  return `<svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">
  <rect width="${size}" height="${size}" rx="${radius}" ry="${radius}" fill="rgb(${r},${g},${b})"/>
</svg>`;
}

/** Resize and center an SVG onto the icon canvas */
function embedSvgIntoBackground(
  backgroundSvg: string,
  symbolSvg: string,
  size: number
): string {
  // Scale symbol to ~60% of canvas size, centered
  const symbolSize = Math.round(size * 0.6);
  const offset = Math.round((size - symbolSize) / 2);

  return `<svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">
  ${backgroundSvg.replace(/<\/?svg[^>]*>/g, "")}
  <g transform="translate(${offset}, ${offset})">
    <svg width="${symbolSize}" height="${symbolSize}" viewBox="0 0 100 100">
      ${symbolSvg.replace(/<\/?svg[^>]*>/g, "")}
    </svg>
  </g>
</svg>`;
}

export interface RenderOptions {
  size?: number; // output PNG size in px (default: 64)
}

/**
 * Render a .shortcut file's icon as a PNG buffer.
 *
 * @param buf - Raw .shortcut file buffer
 * @param opts - Render options
 * @returns PNG buffer
 */
export async function renderIcon(
  buf: Buffer,
  opts: RenderOptions = {}
): Promise<Buffer> {
  const size = opts.size ?? 64;
  const info = await extractIconInfo(buf);

  // Custom image icon — resize and return
  if (info.type === "image" && info.imageData) {
    return sharp(info.imageData).resize(size, size).png().toBuffer();
  }

  // Glyph icon
  const color = info.color!;
  const bgSvg = makeBackground(size, color);

  // Try to fetch the SF Symbol SVG
  let compositedSvg: string;
  const name = info.glyphName;

  if (name) {
    const symbolSvg = await fetchSymbolSvg(name);
    if (symbolSvg) {
      compositedSvg = embedSvgIntoBackground(bgSvg, symbolSvg, size);
    } else {
      // Symbol SVG not found — just return the color background
      compositedSvg = bgSvg;
    }
  } else {
    // Unknown glyph — just the color background
    compositedSvg = bgSvg;
  }

  return sharp(Buffer.from(compositedSvg)).resize(size, size).png().toBuffer();
}

/**
 * Render icon and return as base64 PNG string (for embedding in JSON/HTML).
 */
export async function renderIconBase64(
  buf: Buffer,
  opts: RenderOptions = {}
): Promise<string> {
  const png = await renderIcon(buf, opts);
  return png.toString("base64");
}
